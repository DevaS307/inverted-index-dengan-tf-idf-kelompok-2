import nltk
from nltk import word_tokenize
stemmer = nltk.stem.PorterStemmer()
nltk.download('punkt_tab')
import pandas as pd

def stem(split_query):
    query_stemmed = [stemmer.stem(elt) for elt in split_query]
    return query_stemmed

def clean_tokenize(doc):

    words = word_tokenize(doc.lower())

    return words



def index_one_doc(doc,to_stem):

    '''

    creates dict (tok,positions) for each tok in the document (as term list)

    '''

    tokpos = dict()

    for t_idx,tok in enumerate(doc):

        if to_stem:

           tok = stemmer.stem(tok)

        if tok in tokpos:

            tokpos[tok].append(t_idx)

        else:

            tokpos[tok] = [t_idx]

    return tokpos

def get_docs(path):
    docs = pd.read_excel(path)

    selected_columns = docs[['docs', 'pasal']]

    title = selected_columns.apply(lambda row: f"{row['docs']} {row['pasal']}", axis=1).tolist()

    docs = docs["tentang"].to_list()

    docs = [str(doc) if isinstance(doc, float) else doc for doc in docs]

    cleaned_docs = []

    for doc in docs:
        print(doc)

        to_app = clean_tokenize(str(doc))

        cleaned_docs.append(to_app)

    # print(title)
    # print(cleaned_docs)
    return title, cleaned_docs, docs

def create_index(cleaned_docs):
    inverted_index = dict()
    inverted_index_stem = dict()

    for d_idx, doc in enumerate(cleaned_docs):

        poslists_s = index_one_doc(doc, to_stem=True)  # get positions of each token in the doc
        for tok, poslist_s in poslists_s.items():
            if tok in inverted_index_stem:
                inverted_index_stem[tok][d_idx] = poslist_s  # update
            else:
                inverted_index_stem[tok] = dict()
                inverted_index_stem[tok][d_idx] = poslist_s  # initialize

        poslists = index_one_doc(doc, to_stem=False)
        for tok, poslist in poslists.items():
            if tok in inverted_index:
                inverted_index[tok][d_idx] = poslist
            else:
                inverted_index[tok] = dict()
                inverted_index[tok][d_idx] = poslist

    return inverted_index_stem

def at_least_one_unigram(query,inverted_index):

    '''
    returns the indexes of the docs containing *at least one* query unigrams

    the query is a list of unigrams

    '''



    to_return = []

    for unigram in query:

        if unigram in inverted_index:

            to_return.extend(list(inverted_index[unigram].keys()))

    return list(set(to_return))