from flask import Flask, render_template, request, jsonify
import preprocessing as pre
import model

title, docs, docs_string = pre.get_docs("Kelompok2_new.xlsx")
indexing = pre.create_index(docs)

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        input_text = request.form.get('searchInput')
        print(input_text)
        # Indexing
        split_query = input_text.split()
        query_stemmed = pre.stem(split_query)
        index = pre.at_least_one_unigram(query_stemmed, indexing)

        # Perankingan
        selected_docs = [docs_string[i] for i in index]
        selected_title = [title[i] for i in index]
        query_emb = model.encode(input_text)
        doc_emb = model.encode(selected_docs)
        results = model.ranking(query_emb, doc_emb, selected_title, selected_docs)

        # Convert results to JSON-friendly format
        formatted_results = [
            {"title": r[0], "content": r[1], "score": r[2]} for r in results
        ]

        return jsonify(formatted_results)
    return render_template('index.html')

# @app.route('/', methods=['GET', 'POST'])
# def home():
#     if request.method == 'POST':
#         input_text = request.form.get('searchInput')
#         print(input_text)
#         #indexing
#         split_query = input_text.split()
#         query_stemmed = pre.stem(split_query)
#         # print(query_stemmed)
#         index = pre.at_least_one_unigram(query_stemmed,indexing)
#         # print(index)
#
#         #perankingan
#         selected_docs = [docs_string[i] for i in index]
#         selected_title = [title[i] for i in index]
#         query_emb = model.encode(input_text)
#         doc_emb = model.encode(selected_docs)
#         print(query_emb)
#         results = model.ranking(query_emb,doc_emb,selected_title,selected_docs)
#
#         print(results)
#         return str(results)
#     return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
