from transformers import AutoTokenizer, AutoModel, AdamW
import torch
import torch.nn.functional as F

# Set the device (GPU if available, otherwise CPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load model and tokenizer from HuggingFace Hub, and move model to device
tokenizer = AutoTokenizer.from_pretrained("indolem/indobert-base-uncased")
model = AutoModel.from_pretrained("indolem/indobert-base-uncased").to(device)
# model.load_state_dict(torch.load('/kaggle/working/2_lossvalid0.02850815818263226.pth'))

# Mean Pooling - Take average of all tokens
def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output.last_hidden_state
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)


# Encode text
def encode(texts):
    # Tokenize sentences
    encoded_input = tokenizer(texts, padding=True, truncation=True, max_length=512, return_tensors='pt').to(device)

    # Compute token embeddings
    with torch.no_grad():
        model_output = model(**encoded_input, return_dict=True)

    # Perform pooling
    embeddings = mean_pooling(model_output, encoded_input['attention_mask'])

    # Normalize embeddings
    embeddings = F.normalize(embeddings, p=2, dim=1)

    return embeddings

def ranking(query_emb, doc_emb, title, docs):
    # Compute dot score between query and all document embeddings
    scores = torch.mm(query_emb, doc_emb.transpose(0, 1))[0].cpu().tolist()

    # Combine docs, titles & scores
    doc_score_pairs = list(zip(title, docs, scores))

    # Sort by decreasing score
    doc_score_pairs = sorted(doc_score_pairs, key=lambda x: x[2], reverse=True)

    # Output passages & scores
    for title, doc, score in doc_score_pairs:
        print(f"Title: {title}, Score: {score:.4f}\nDoc: {doc}\n")

    return doc_score_pairs

# # Contoh query embedding (1 query)
# query_emb = torch.tensor([[0.1, 0.2, 0.3]])
#
# # Contoh document embeddings (3 dokumen)
# doc_emb = torch.tensor([
#     [0.4, 0.5, 0.6],
#     [0.1, 0.3, 0.5],
#     [0.2, 0.2, 0.2]
# ])
#
# # Contoh data
# titles = ["Doc 1", "Doc 2", "Doc 3"]
# docs = ["Content of document 1", "Content of document 2", "Content of document 3"]
#
# # Pemanggilan fungsi
# ranked_docs = ranking(query_emb, doc_emb, titles, docs)

